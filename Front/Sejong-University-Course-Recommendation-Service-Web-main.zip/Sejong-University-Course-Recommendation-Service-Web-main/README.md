# Sejong-University-Course-Recommendation-Service-Web
2023-1 세종대학교 창의학기제 직업별 교과목 및 비교과 활동 추천 웹/앱 서비스
